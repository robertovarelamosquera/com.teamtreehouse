import java.util.Random;

public class Jar {
        int maxNumber;
        String itemName;
        public Jar (int maxNumber, String itemName){
            this.maxNumber=maxNumber;
            this.itemName=itemName;
        }
         public int fill()
        {
            Random random = new Random();
            //int someNumber = random.nextInt(maxNumber);
            int min=1;
            int someNumber = random.nextInt((maxNumber - min) + 1) + min;
            return someNumber;
        }  
}
