import java.util.Scanner;
import java.util.Random;
public class Game {                                
public static void main (String args[]){
        int guess;
        int attempts=0;
        Scanner scanner = new Scanner(System.in);
        System.out.println("ADMINISTRATOR");
        System.out.println("=============");
        System.out.println("Name of items in the jar: ");
        String items = scanner.next();
        System.out.println("Maximum number of " + items + " in the jar: ");
        int maxNumber = Integer.parseInt(scanner.next());
        System.out.println("PLAYER");
        System.out.println("======");
        System.out.println("Your goal is to guess how many " + items + " are in the jar. "
                + "Your guess should be between  1 and " + maxNumber);
        System.out.println("Ready? ");
        Jar myJar = new Jar(maxNumber,items); 
        int goal=myJar.fill();
            do
            { 
                System.out.print("Guess: ");
                guess = Integer.parseInt(scanner.next());
                if (guess> maxNumber) {
                    System.out.println("Your guess must be less than " + maxNumber);
                    continue;
                }
                attempts++;
                if (guess==goal) break;
                if (guess>goal){
                    System.out.println("Your guess is too high");
                }
                else
                {
                   System.out.println("Your guess is too low"); 
                }          
            }while (goal!=guess);   
            
            System.out.println("Congratulations - you guessed that there are " + goal + " "+ items + " in the jar: "
                + "it took you " + attempts + " guess (es) to get it right.");           
}
}
